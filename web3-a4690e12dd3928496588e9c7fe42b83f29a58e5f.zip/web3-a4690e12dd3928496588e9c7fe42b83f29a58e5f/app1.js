document.addEventListener('DOMContentLoaded', () => {
    const connectButton = document.getElementById('connectButton');
    const sendButton = document.getElementById('sendButton');
    const walletAddress = document.getElementById('walletAddress');
    const status = document.getElementById('status');
  
    let web3;
    let account;
  
    connectButton.addEventListener('click', async () => {
      console.log('Connect button clicked');
      if (typeof window.ethereum !== 'undefined') {
        console.log('MetaMask is detected');
        web3 = new Web3(window.ethereum);
        try {
          await window.ethereum.request({ method: 'eth_requestAccounts' });
          const accounts = await web3.eth.getAccounts();
          account = accounts[0];
          walletAddress.innerText = `Connected: ${account}`;
          status.innerText = '';
        } catch (error) {
          console.error(error);
          status.innerText = 'Failed to connect MetaMask';
        }
      } else {
        console.log('MetaMask is not detected');
        status.innerText = 'MetaMask is not installed. Please install MetaMask and try again.';
      }
    });
  
    sendButton.addEventListener('click', async () => {
      const recipient = document.getElementById('recipient').value;
      const amount = document.getElementById('amount').value;
  
      if (!web3 || !account) {
        status.innerText = 'Please connect MetaMask first';
        return;
      }
  
      const tokenAddress = 'YOUR_TOKEN_CONTRACT_ADDRESS'; // Replace with your token contract address
      const tokenABI = [
        // ... (rest of the ABI)
      ]; // Replace with your token contract ABI
  
      const tokenContract = new web3.eth.Contract(tokenABI, tokenAddress);
  
      try {
        await tokenContract.methods.transfer(recipient, web3.utils.toWei(amount, 'ether')).send({ from: account });
        status.innerText = 'Transaction successful';
      } catch (error) {
        console.error(error);
        status.innerText = 'Transaction failed';
      }
    });
  });